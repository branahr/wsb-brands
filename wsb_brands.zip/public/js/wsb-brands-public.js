jQuery(document).ready( function($) {

	$('.wsb-brands-carousel-wrap').slick({
    	autoplay: true,
		autoplaySpeed: 4000
  	});
  
});